# 剧果短剧（黄果）· 纯脚本插件

不含 HSP，ZIP 导入即可。接口来自 `api.huangju.net`：

| 钩子 | 请求 |
| --- | --- |
| `data.search` | `POST /auth/guest` 换游客 Token → `GET /dramas?page&q` |
| `data.detail` | `POST /auth/guest` → `GET /dramas/{slug}-{id}`，用 `detailcard` 生成选集 |
| `media.beforePlay` | `POST /auth/guest` → `GET /play/{episodeId}`，取出 HLS 地址 |

## 播放为什么要新 HAP

黄果的 `/play/{episodeId}` 返回 HLS 地址，同时通过 `Set-Cookie` 下发 CloudFront 鉴权 Cookie：

```text
CloudFront-Policy / CloudFront-Signature / CloudFront-Key-Pair-Id
```

不带 Cookie 请求 HLS 会得到 403。脚本引擎现在会：

1. 解析 HTTP 响应里的 `Set-Cookie`；
2. 在 `media.beforePlay` 结果里带上 `cookie`；
3. 宿主用 `media.createMediaSourceWithUrl(url, { Cookie })` 创建 AVPlayer MediaSource。

因此必须使用**包含 Cookie/MediaSource 支持的 HAP**；旧 HAP 只会用 `instance.url`，播放会 403。

## 使用

1. 安装新版 HAP；
2. 插件中心导入本 ZIP；
3. 启用；
4. 搜索剧名 → 点击卡片 → 宿主回查详情 → 播放。

## 说明

- 游客 Token 每次钩子重新获取，不落盘；设备 ID 使用插件内置的固定 UUID。
- 播放地址是 HLS，Cookie 有效期约 6 小时；过期后重新进入播放即可换新。
- 接口内容、可用性由黄果站点决定；本插件只做请求与字段映射，不下载、不存储视频。
