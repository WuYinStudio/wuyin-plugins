# B站弹幕插件（纯脚本）

输入片名 → 自动完成「搜索页 → BV 号 → cid → 弹幕 XML」，全程不需要签名或 Cookie。

## 链路

```
GET https://search.bilibili.com/all?keyword=<片名>      → HTML，正则抓 BV 号
GET https://api.bilibili.com/x/player/pagelist?bvid=<BV> → {"data":[{"cid":...}]}
GET https://comment.bilibili.com/<cid>.xml              → 标准弹幕 XML
```

宿主的 `DanmakuService.parse()` 能自动识别这种 XML：

```ts
if (/<i\b[^>]*\bp=/.test(content) && /<d\b/.test(content)) { return DanmakuService.parseBiliXml(content); }
```

## 配置

| 键 | 说明 |
|---|---|
| `quality` | `first` 取第一个结果 / `video` 优先正片 |

## 宿主接入方式

播放器在 `prepared` 后调用一次：

```ts
const payload = new PluginHookPayload();
payload.hook = PluginHookName.MEDIA_SUBTITLE;
payload.text = 片名;
const results = await PluginHooks.dispatchAll(PluginHookName.MEDIA_SUBTITLE, payload);
// results[].text 就是弹幕 XML
```
