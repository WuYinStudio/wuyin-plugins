﻿# 红果在线站源插件（HSP）

把 `com_wuyin_shortvideo` 里已经跑通的红果（openhongguo）接口，按《无音影视插件开发文档 v5.1.6》包装成宿主插件。

## 为什么是 HSP 而不是 script

| 需求 | script 插件 | HSP 插件 |
| --- | --- | --- |
| 红果请求签名（X-Gorgon / X-Helios / X-Ladon，SM3+MD5+AES） | ❌ 23 个 op 里没有任何哈希/加密能力 | ✅ 完整 ArkTS |
| 片源 CENC 解密（AES-CTR） | ❌ | ✅ 复用移植的 `ohg/Cenc.ets` |
| 宿主只接受 `http(s)://` 播放地址 | — | ✅ 插件内起 `127.0.0.1` HTTP 服务提供解密后的片段 |

## 结构

```
hongguo-hsp/
├─ manifest.json                插件清单（hooks: data.search / data.detail / media.beforePlay）
├─ library/
│  ├─ Index.ets                 export { HongguoPlugin, createPlugin }
│  └─ src/main/ets/
│     ├─ PluginContract.ets     宿主公开契约（照抄宿主）
│     ├─ PluginEntry.ets        钩子实现
│     ├─ ohg/                   移植的红果客户端（16 个文件 + Log 适配）
│     └─ media/
│        ├─ ClipStore.ets       下载 → CENC 解密 → 存入内存
│        └─ LocalMediaServer.ets 127.0.0.1 HTTP 服务（支持 Range）
```

## 三个钩子

| 钩子 | 作用 |
| --- | --- |
| `data.search` | 调红果搜索（带签名），每个剧集输出一张卡片，`playUrl` 指向本地片段 URL |
| `data.detail` | 取分集列表，生成 `第 N 集` 的本地 URL 列表 |
| `media.beforePlay` | 播放前确保该集已解密并缓存，返回同一个本地 URL；未命中则原样放行 |

## 构建

```powershell
cd plugin-templates/hongguo-hsp
hvigorw assembleHsp --mode module -p module=wuyin_plugin_hongguo@default `
  -p product=default -p buildMode=release
```

产物：`library/build/default/outputs/default/wuyin_plugin_hongguo-default-*.hsp`（约 750 KB）。

## 集成到宿主（必须，HSP 不能单独安装生效）

1. 宿主 `build-profile.json5` 的 `modules` 增加：

```json5
{ "name": "wuyin_plugin_hongguo", "srcPath": "./plugin-templates/hongguo-hsp/library",
  "targets": [{ "name": "default", "applyToProducts": ["default"] }] }
```

2. 宿主入口注册（只注册一次）：

```ts
import { createPlugin } from 'wuyin_plugin_hongguo';
HspRegistry.register('wuyin.hongguo', 'wuyin_plugin_hongguo', createPlugin);
```

3. 用**与宿主相同的签名**构建 app；插件与宿主签名不一致时系统会拒绝加载。

## 已知限制

- 解密片段常驻内存，最多保留 2 集（约 6–18 MB），切集时淘汰最旧的。
- `data.search` 每张卡片只给第 1 集，完整分集走 `data.detail`。
- 本地端口固定尝试 `46811`，被占用时 `onEnable` 会在日志里报错。
- 首集需要下载 + 解密（约 3–9 秒），`media.beforePlay` 有 3 秒超时，超时会先用原地址（本地服务尚未就绪 → 播放失败）；第二集起有预取会更稳。
